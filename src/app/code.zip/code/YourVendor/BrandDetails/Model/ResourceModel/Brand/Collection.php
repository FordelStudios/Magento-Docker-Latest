<?php
namespace YourVendor\BrandDetails\Model\ResourceModel\Brand;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'brand_details_collection';

    /**
     * Initialize collection model
     */
    protected function _construct()
    {
        $this->_init(
            \YourVendor\BrandDetails\Model\Brand::class,
            \YourVendor\BrandDetails\Model\ResourceModel\Brand::class
        );
    }
}